.section .text
.global app
app:
    mov x10, x0
    // Fondo rojo
    mov x1, #0
    mov x2, #0
    mov x3, #512
    mov x4, #512
    movz w5, #0xF800
    bl draw_rect
    // Borde exterior azul
    movz w5, #0x001F
    mov x1, #15
    mov x2, #15
    mov x3, #482
    mov x4, #10
    bl draw_rect
    mov x1, #15
    mov x2, #15
    mov x3, #10
    mov x4, #482
    bl draw_rect
    mov x1, #487
    mov x2, #15
    mov x3, #10
    mov x4, #482
    bl draw_rect
    mov x1, #15
    mov x2, #487
    mov x3, #419
    mov x4, #10
    bl draw_rect
    // Entrada superior roja
    movz w5, #0xF800
    mov x1, #67
    mov x2, #15
    mov x3, #63
    mov x4, #10
    bl draw_rect
    // Paredes horizontales azules; el hueco alterna para formar serpentina
    movz w5, #0x001F
    // Pared en y=67, hueco derecho
    mov x1, #25
    mov x2, #67
    mov x3, #420
    mov x4, #6
    bl draw_rect
    // Pared en y=109, hueco izquierdo
    mov x1, #67
    mov x2, #109
    mov x3, #420
    mov x4, #6
    bl draw_rect
    // Pared en y=151, hueco derecho
    mov x1, #25
    mov x2, #151
    mov x3, #420
    mov x4, #6
    bl draw_rect
    // Pared en y=193, hueco izquierdo
    mov x1, #67
    mov x2, #193
    mov x3, #420
    mov x4, #6
    bl draw_rect
    // Pared en y=235, hueco derecho
    mov x1, #25
    mov x2, #235
    mov x3, #420
    mov x4, #6
    bl draw_rect
    // Pared en y=277, hueco izquierdo
    mov x1, #67
    mov x2, #277
    mov x3, #420
    mov x4, #6
    bl draw_rect
    // Pared en y=319, hueco derecho
    mov x1, #25
    mov x2, #319
    mov x3, #420
    mov x4, #6
    bl draw_rect
    // Pared en y=361, hueco izquierdo
    mov x1, #67
    mov x2, #361
    mov x3, #420
    mov x4, #6
    bl draw_rect
    // Pared en y=403, hueco derecho
    mov x1, #25
    mov x2, #403
    mov x3, #420
    mov x4, #6
    bl draw_rect
    // Pared en y=445, hueco izquierdo
    mov x1, #67
    mov x2, #445
    mov x3, #420
    mov x4, #6
    bl draw_rect
    // Divisores cortos adicionales
    mov x1, #180
    mov x2, #73
    mov x3, #6
    mov x4, #30
    bl draw_rect
    mov x1, #325
    mov x2, #115
    mov x3, #6
    mov x4, #30
    bl draw_rect
    mov x1, #180
    mov x2, #157
    mov x3, #6
    mov x4, #30
    bl draw_rect
    mov x1, #325
    mov x2, #199
    mov x3, #6
    mov x4, #30
    bl draw_rect
    mov x1, #180
    mov x2, #241
    mov x3, #6
    mov x4, #30
    bl draw_rect
    // Personaje verde 26x26 en la entrada
    movz w5, #0x07E0
    mov x1, #80
    mov x2, #28
    mov x3, #26
    mov x4, #26
    bl draw_rect
InfLoop:
    b InfLoop
// draw_rect: X10=base, X1=x, X2=y, X3=ancho, X4=alto, W5=color
draw_rect:
    mov x6, x2
    mov x7, x4
row_loop:
    cbz x7, rect_done
    mov x8, x3
    lsl x9, x6, #9
    add x9, x9, x1
    lsl x9, x9, #1
    add x9, x10, x9
col_loop:
    cbz x8, next_row
    sturh w5, [x9]
    add x9, x9, #2
    sub x8, x8, #1
    b col_loop
next_row:
    add x6, x6, #1
    sub x7, x7, #1
    b row_loop
rect_done:
    ret
